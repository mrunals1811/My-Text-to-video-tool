async function generateVideo() {
  const text = document.getElementById("inputText").value;

  document.getElementById("result").innerHTML = "Generating video...";

  const response = await fetch("./api-generate.js", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ prompt: text }),
  });

  const result = await response.json();

  if (result.videoUrl) {
    document.getElementById("result").innerHTML = `
      <video width="300" controls>
        <source src="${result.videoUrl}" type="video/mp4">
      </video>`;
  } else {
    document.getElementById("result").innerHTML = "Error generating video.";
  }
}
