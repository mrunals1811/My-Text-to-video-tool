import Replicate from "https://cdn.jsdelivr.net/npm/replicate@latest";

export default async function handler(req, res) {
  const { prompt } = req.body;

  const replicate = new Replicate({ auth: "YOUR_API_KEY_HERE" });

  const output = await replicate.run(
    "yoru/sora:latest",
    { input: { prompt } }
  );

  res.json({ videoUrl: output.video });
}
