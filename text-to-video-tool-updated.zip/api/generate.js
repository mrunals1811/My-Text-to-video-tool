import Replicate from "replicate";

export default async function handler(req, res) {
  try {
    const { prompt } = req.body;

    const replicate = new Replicate({
      auth: process.env.REPLICATE_API_TOKEN
    });

    const output = await replicate.run(
      "yoru/sora:latest",
      { input: { prompt } }
    );

    res.status(200).json({ videoUrl: output.video });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
